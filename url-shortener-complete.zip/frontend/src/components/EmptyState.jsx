import React from 'react';
import { Link2 } from 'lucide-react';

export default function EmptyState({ title = 'No items found', description = 'Try creating a new link or checking back later.', actionButton }) {
  return (
    <div className="flex flex-col items-center justify-center p-12 text-center border border-dashed border-border-light dark:border-border-dark rounded-xl bg-card-light/50 dark:bg-card-dark/20 backdrop-blur-sm">
      <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/10 text-indigo-500 mb-4 animate-bounce">
        <Link2 className="w-6 h-6" />
      </div>
      <h3 className="text-lg font-semibold text-zinc-900 dark:text-zinc-50 mb-1">{title}</h3>
      <p className="text-sm text-zinc-500 dark:text-zinc-400 max-w-sm mb-6 leading-relaxed">{description}</p>
      {actionButton && (
        <div className="flex justify-center">
          {actionButton}
        </div>
      )}
    </div>
  );
}
