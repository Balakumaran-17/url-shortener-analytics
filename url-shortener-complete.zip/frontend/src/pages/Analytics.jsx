import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAnalyticsStore } from '../store/analyticsStore';
import { useUrlStore } from '../store/urlStore';
import toast from 'react-hot-toast';
import Pagination from '../components/Pagination';
import EmptyState from '../components/EmptyState';
import { ChartSkeleton, TableSkeleton } from '../components/Skeleton';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend
} from 'recharts';
import { 
  Calendar, 
  Globe, 
  Compass, 
  ArrowLeft,
  Download,
  CalendarCheck,
  MousePointerClick
} from 'lucide-react';

const COLORS = ['#6366f1', '#10b981', '#3b82f6', '#f59e0b', '#ec4899', '#8b5cf6'];

export default function Analytics() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { urlAnalytics, isLoading, fetchUrlAnalyticsAction, dashboardSummary, fetchDashboardSummaryAction } = useAnalyticsStore();
  const { urls, fetchUrlsAction } = useUrlStore();

  const [visitPage, setVisitPage] = useState(1);
  const [selectedLinkId, setSelectedLinkId] = useState(id || '');

  useEffect(() => {
    // If we have select URLs in store, use them, otherwise fetch
    if (urls.length === 0) {
      fetchUrlsAction().catch(() => {});
    }
  }, []);

  useEffect(() => {
    if (id) {
      setSelectedLinkId(id);
      fetchUrlAnalyticsAction(id, { page: visitPage, limit: 8 }).catch((err) => {
        toast.error('Failed to load link analytics: ' + err.message);
        navigate('/analytics');
      });
    } else {
      setSelectedLinkId('');
      fetchDashboardSummaryAction().catch(() => {});
    }
  }, [id, visitPage]);

  const handleLinkSelectChange = (e) => {
    const nextId = e.target.value;
    if (nextId) {
      navigate(`/analytics/${nextId}`);
    } else {
      navigate('/analytics');
    }
    setVisitPage(1);
  };

  // Helper: Export analytics data to CSV
  const handleExportCSV = () => {
    if (!urlAnalytics) return;
    
    const visits = urlAnalytics.visitsTable.visits;
    if (visits.length === 0) {
      toast.error('No click records available to export.');
      return;
    }

    const headers = ['Timestamp', 'IP Address', 'Browser', 'Device', 'Operating System', 'Referrer', 'Country', 'City'];
    const rows = visits.map(v => [
      new Date(v.timestamp).toISOString(),
      '***.***.***.***', // Anonymized IP for privacy
      v.browser,
      v.device,
      v.os,
      v.referrer,
      v.country,
      v.city
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.map(val => `"${val}"`).join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `analytics-${urlAnalytics.url.shortCode}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('CSV Export downloaded!');
  };

  // Render Aggregate view if no ID
  if (!id) {
    return (
      <div className="space-y-8 animate-in fade-in duration-200">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50">Global Analytics</h2>
            <p className="text-sm text-zinc-500 dark:text-zinc-400">
              Aggregated click distribution and browser metrics across all links
            </p>
          </div>
          
          {/* Select dropdown */}
          <div className="flex items-center space-x-3">
            <span className="text-sm font-semibold text-zinc-500">Analyze Link:</span>
            <select
              value={selectedLinkId}
              onChange={handleLinkSelectChange}
              className="px-3 py-2 text-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-lg text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="">Global Overall Stats</option>
              {urls.map(u => (
                <option key={u._id} value={u._id}>/{u.shortCode}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Global Summary charts */}
        {!dashboardSummary ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <ChartSkeleton />
            <ChartSkeleton />
            <ChartSkeleton />
          </div>
        ) : (
          <>
            {/* Click Volume over 7 days */}
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl">
              <h3 className="text-lg font-bold mb-4">Click Activity (Last 7 Days)</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={dashboardSummary.dailyClicks}>
                    <defs>
                      <linearGradient id="colorClicksGlobal" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                    <XAxis dataKey="date" stroke="#71717a" fontSize={11} />
                    <YAxis stroke="#71717a" fontSize={11} allowDecimals={false} />
                    <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', color: '#fafafa' }} />
                    <Area type="monotone" dataKey="clicks" stroke="#6366f1" strokeWidth={2.5} fillOpacity={1} fill="url(#colorClicksGlobal)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Browser & Device Distribution grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Browser Stats */}
              <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl">
                <h3 className="text-md font-bold mb-4">Top Browsers</h3>
                {dashboardSummary.browserStats.length === 0 ? (
                  <div className="h-48 flex items-center justify-center text-zinc-400 text-sm">No browser statistics logged yet</div>
                ) : (
                  <div className="h-60 flex items-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={dashboardSummary.browserStats}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {dashboardSummary.browserStats.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', color: '#fafafa' }} />
                        <Legend verticalAlign="bottom" height={36} iconSize={10} iconType="circle" />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>

              {/* Device Stats */}
              <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl">
                <h3 className="text-md font-bold mb-4">Device Split</h3>
                {dashboardSummary.deviceStats.length === 0 ? (
                  <div className="h-48 flex items-center justify-center text-zinc-400 text-sm">No device statistics logged yet</div>
                ) : (
                  <div className="h-60">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={dashboardSummary.deviceStats}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                        <XAxis dataKey="name" stroke="#71717a" fontSize={11} />
                        <YAxis stroke="#71717a" fontSize={11} allowDecimals={false} />
                        <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', color: '#fafafa' }} />
                        <Bar dataKey="value" name="Total Clicks" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>

            </div>
          </>
        )}

      </div>
    );
  }

  // Render Detailed individual link view
  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      
      {/* Top Header Card */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <Link 
            to="/analytics" 
            className="p-2 border border-border-light dark:border-border-dark rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-100 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50">Link Analytics</h2>
              {urlAnalytics && (
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-zinc-500">
                  /{urlAnalytics.url.shortCode}
                </span>
              )}
            </div>
            {urlAnalytics && (
              <p className="text-sm text-zinc-500 dark:text-zinc-400 max-w-lg truncate">
                {urlAnalytics.url.longUrl}
              </p>
            )}
          </div>
        </div>

        {/* Actions panel */}
        <div className="flex items-center gap-3">
          {urlAnalytics && (
            <button
              onClick={handleExportCSV}
              className="flex items-center space-x-2 px-3 py-2 border border-border-light dark:border-border-dark hover:bg-zinc-100 dark:hover:bg-zinc-800 text-sm font-semibold rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </button>
          )}
          <select
            value={selectedLinkId}
            onChange={handleLinkSelectChange}
            className="px-3 py-2 text-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-lg text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="">Global Overall Stats</option>
            {urls.map(u => (
              <option key={u._id} value={u._id}>/{u.shortCode}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Charts & Table section */}
      {!urlAnalytics && isLoading ? (
        <div className="space-y-6">
          <ChartSkeleton />
          <TableSkeleton />
        </div>
      ) : !urlAnalytics ? (
        <EmptyState title="URL details not found" description="The URL requested could not be verified." />
      ) : (
        <>
          {/* Quick numbers card summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl flex items-center space-x-4">
              <div className="w-10 h-10 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
                <MousePointerClick className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">Total Clicks</p>
                <p className="text-2xl font-black text-zinc-900 dark:text-zinc-100">{urlAnalytics.summary.totalClicks}</p>
              </div>
            </div>
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl flex items-center space-x-4">
              <div className="w-10 h-10 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
                <CalendarCheck className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">Last Visit Time</p>
                <p className="text-sm font-bold text-zinc-900 dark:text-zinc-100">
                  {urlAnalytics.summary.lastVisitedTime 
                    ? new Date(urlAnalytics.summary.lastVisitedTime).toLocaleString()
                    : 'Never visited'}
                </p>
              </div>
            </div>
          </div>

          {/* Time Series click chart over 30 days */}
          <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl">
            <h3 className="text-md font-bold mb-4">Daily Click History (Last 30 Days)</h3>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={urlAnalytics.charts.dailyClicks}>
                  <defs>
                    <linearGradient id="colorClicksLink" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#818cf8" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#818cf8" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                  <XAxis dataKey="date" stroke="#71717a" fontSize={10} />
                  <YAxis stroke="#71717a" fontSize={10} allowDecimals={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', color: '#fafafa' }} />
                  <Area type="monotone" dataKey="clicks" stroke="#818cf8" strokeWidth={2.5} fillOpacity={1} fill="url(#colorClicksLink)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Metrics Distributions */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            {/* Devices */}
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl">
              <h3 className="text-sm font-bold mb-4">Devices</h3>
              {urlAnalytics.charts.deviceStats.length === 0 ? (
                <div className="text-center py-10 text-zinc-500 text-xs">No logs recorded</div>
              ) : (
                <div className="space-y-4">
                  {urlAnalytics.charts.deviceStats.map((item, idx) => {
                    const pct = Math.round((item.value / urlAnalytics.summary.totalClicks) * 100);
                    return (
                      <div key={item.name} className="space-y-1">
                        <div className="flex justify-between text-xs font-semibold">
                          <span>{item.name}</span>
                          <span>{item.value} ({pct}%)</span>
                        </div>
                        <div className="h-2 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-indigo-500 rounded-full" 
                            style={{ width: `${pct}%` }} 
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* OS */}
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl">
              <h3 className="text-sm font-bold mb-4">Operating Systems</h3>
              {urlAnalytics.charts.osStats.length === 0 ? (
                <div className="text-center py-10 text-zinc-500 text-xs">No logs recorded</div>
              ) : (
                <div className="space-y-4">
                  {urlAnalytics.charts.osStats.map((item, idx) => {
                    const pct = Math.round((item.value / urlAnalytics.summary.totalClicks) * 100);
                    return (
                      <div key={item.name} className="space-y-1">
                        <div className="flex justify-between text-xs font-semibold">
                          <span>{item.name}</span>
                          <span>{item.value} ({pct}%)</span>
                        </div>
                        <div className="h-2 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-emerald-500 rounded-full" 
                            style={{ width: `${pct}%` }} 
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Referrers */}
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl">
              <h3 className="text-sm font-bold mb-4">Referrer Channels</h3>
              {urlAnalytics.charts.referrerStats.length === 0 ? (
                <div className="text-center py-10 text-zinc-500 text-xs">No logs recorded</div>
              ) : (
                <div className="space-y-4">
                  {urlAnalytics.charts.referrerStats.map((item, idx) => {
                    const pct = Math.round((item.value / urlAnalytics.summary.totalClicks) * 100);
                    return (
                      <div key={item.name} className="space-y-1">
                        <div className="flex justify-between text-xs font-semibold">
                          <span>{item.name}</span>
                          <span>{item.value} ({pct}%)</span>
                        </div>
                        <div className="h-2 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-blue-500 rounded-full" 
                            style={{ width: `${pct}%` }} 
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Countries */}
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl">
              <h3 className="text-sm font-bold mb-4">Geographic Countries</h3>
              {urlAnalytics.charts.countryStats.length === 0 ? (
                <div className="text-center py-10 text-zinc-500 text-xs">No logs recorded</div>
              ) : (
                <div className="space-y-4">
                  {urlAnalytics.charts.countryStats.map((item, idx) => {
                    const pct = Math.round((item.value / urlAnalytics.summary.totalClicks) * 100);
                    return (
                      <div key={item.name} className="space-y-1">
                        <div className="flex justify-between text-xs font-semibold">
                          <span>{item.name}</span>
                          <span>{item.value} ({pct}%)</span>
                        </div>
                        <div className="h-2 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-amber-500 rounded-full" 
                            style={{ width: `${pct}%` }} 
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Cities */}
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl">
              <h3 className="text-sm font-bold mb-4">Geographic Cities</h3>
              {urlAnalytics.charts.cityStats.length === 0 ? (
                <div className="text-center py-10 text-zinc-500 text-xs">No logs recorded</div>
              ) : (
                <div className="space-y-4">
                  {urlAnalytics.charts.cityStats.map((item, idx) => {
                    const pct = Math.round((item.value / urlAnalytics.summary.totalClicks) * 100);
                    return (
                      <div key={item.name} className="space-y-1">
                        <div className="flex justify-between text-xs font-semibold">
                          <span>{item.name}</span>
                          <span>{item.value} ({pct}%)</span>
                        </div>
                        <div className="h-2 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-violet-500 rounded-full" 
                            style={{ width: `${pct}%` }} 
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>

          {/* Paginated Visit Logs Table */}
          <div className="overflow-hidden border border-border-light dark:border-border-dark rounded-xl bg-card-light dark:bg-card-dark">
            <div className="px-6 py-4 border-b border-border-light dark:border-border-dark">
              <h3 className="font-bold text-zinc-800 dark:text-zinc-200">Recent Visitors Log</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-zinc-50 dark:bg-zinc-900/50 text-xs font-semibold uppercase tracking-wider text-zinc-400 border-b border-border-light dark:border-border-dark">
                    <th className="px-6 py-3">Timestamp</th>
                    <th className="px-6 py-3">Location</th>
                    <th className="px-6 py-3">Device / OS</th>
                    <th className="px-6 py-3">Browser</th>
                    <th className="px-6 py-3">Referrer</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-light dark:divide-border-dark text-xs">
                  {urlAnalytics.visitsTable.visits.map((visit) => (
                    <tr key={visit._id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/10 transition-colors">
                      <td className="px-6 py-3 whitespace-nowrap text-zinc-500">
                        {new Date(visit.timestamp).toLocaleString()}
                      </td>
                      <td className="px-6 py-3 whitespace-nowrap font-medium text-zinc-700 dark:text-zinc-200">
                        {visit.city}, {visit.country}
                      </td>
                      <td className="px-6 py-3 whitespace-nowrap text-zinc-500">
                        {visit.device} / {visit.os}
                      </td>
                      <td className="px-6 py-3 whitespace-nowrap text-zinc-500">
                        {visit.browser}
                      </td>
                      <td className="px-6 py-3 whitespace-nowrap text-zinc-500">
                        {visit.referrer}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <Pagination 
              currentPage={urlAnalytics.visitsTable.currentPage} 
              totalPages={urlAnalytics.visitsTable.totalPages} 
              onPageChange={(p) => setVisitPage(p)} 
            />
          </div>
        </>
      )}

    </div>
  );
}
