import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useUrlStore } from '../store/urlStore';
import { useAnalyticsStore } from '../store/analyticsStore';
import toast from 'react-hot-toast';
import SearchBar from '../components/SearchBar';
import Pagination from '../components/Pagination';
import ConfirmModal from '../components/ConfirmModal';
import EmptyState from '../components/EmptyState';
import { CardSkeleton, TableSkeleton } from '../components/Skeleton';
import { 
  Plus, 
  Copy, 
  Trash2, 
  Edit3, 
  QrCode, 
  ExternalLink, 
  Link2, 
  Calendar,
  MousePointerClick,
  CheckCircle,
  Clock,
  X,
  Download
} from 'lucide-react';

export default function Dashboard() {
  const { urls, totalCount, totalPages, currentPage, isLoading, fetchUrlsAction, createUrlAction, updateUrlAction, deleteUrlAction } = useUrlStore();
  const { dashboardSummary, fetchDashboardSummaryAction } = useAnalyticsStore();

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');
  
  // Modals state
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isQrOpen, setIsQrOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  
  // Selection states
  const [selectedUrl, setSelectedUrl] = useState(null);
  const [newUrlData, setNewUrlData] = useState({ longUrl: '', customAlias: '', expiresAt: '' });
  const [editUrlData, setEditUrlData] = useState({ longUrl: '', expiresAt: '' });
  
  // Copy state feedback
  const [copiedId, setCopiedId] = useState(null);

  useEffect(() => {
    // Initial fetch of metrics and link table
    fetchDashboardSummaryAction().catch(() => {});
    fetchUrlsAction({ page, search: searchQuery, status: statusFilter }).catch(() => {});
  }, [page, searchQuery, statusFilter]);

  const handlePageChange = (newPage) => {
    setPage(newPage);
  };

  const handleCopyLink = (urlObj) => {
    // Construct redirect link
    const redirectLink = `${window.location.protocol}//${window.location.host.replace('5173', '5000')}/${urlObj.shortCode}`;
    navigator.clipboard.writeText(redirectLink);
    setCopiedId(urlObj._id);
    toast.success('Short link copied to clipboard!');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCreateLink = async (e) => {
    e.preventDefault();
    if (!newUrlData.longUrl) {
      toast.error('Destination URL is required');
      return;
    }

    try {
      const created = await createUrlAction(newUrlData);
      toast.success('Link shortened successfully!');
      setNewUrlData({ longUrl: '', customAlias: '', expiresAt: '' });
      setIsCreateOpen(false);
      // Refresh summary metrics
      fetchDashboardSummaryAction().catch(() => {});
    } catch (err) {
      toast.error(err.message || 'Failed to shorten URL');
    }
  };

  const handleEditLink = async (e) => {
    e.preventDefault();
    if (!editUrlData.longUrl) {
      toast.error('Destination URL is required');
      return;
    }

    try {
      await updateUrlAction(selectedUrl._id, editUrlData);
      toast.success('Link updated successfully!');
      setIsEditOpen(false);
      setSelectedUrl(null);
    } catch (err) {
      toast.error(err.message || 'Failed to update URL');
    }
  };

  const handleDeleteLink = async () => {
    try {
      await deleteUrlAction(selectedUrl._id);
      toast.success('Link deleted successfully!');
      setIsDeleteOpen(false);
      setSelectedUrl(null);
      // Refresh summary metrics
      fetchDashboardSummaryAction().catch(() => {});
    } catch (err) {
      toast.error(err.message || 'Failed to delete URL');
    }
  };

  // Helper for status classes
  const getStatusBadge = (status, expiresAt) => {
    if (expiresAt && new Date(expiresAt) < new Date()) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-400">
          Expired
        </span>
      );
    }
    if (status === 'active') {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400">
          Active
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-400">
        Inactive
      </span>
    );
  };

  return (
    <div className="space-y-8">
      
      {/* Top Header Card */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50">Overview</h2>
          <p className="text-sm text-zinc-500 dark:text-zinc-400">
            Create shortened URLs, retrieve QR Codes, and track click statistics
          </p>
        </div>
        <button
          onClick={() => setIsCreateOpen(true)}
          className="flex items-center justify-center space-x-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg shadow-lg shadow-indigo-600/20 active:scale-[0.98] transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Shorten Link</span>
        </button>
      </div>

      {/* Aggregate metrics grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {!dashboardSummary ? (
          [...Array(4)].map((_, i) => <CardSkeleton key={i} />)
        ) : (
          <>
            {/* Total Links */}
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl flex items-center justify-between hover:shadow-md transition-shadow">
              <div className="space-y-1">
                <p className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">Total Links</p>
                <p className="text-3xl font-extrabold text-zinc-900 dark:text-zinc-50">{dashboardSummary.cards.totalLinks}</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
                <Link2 className="w-5 h-5" />
              </div>
            </div>

            {/* Total Clicks */}
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl flex items-center justify-between hover:shadow-md transition-shadow">
              <div className="space-y-1">
                <p className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">Total Clicks</p>
                <p className="text-3xl font-extrabold text-zinc-900 dark:text-zinc-50">{dashboardSummary.cards.totalClicks}</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                <MousePointerClick className="w-5 h-5" />
              </div>
            </div>

            {/* Active Links */}
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl flex items-center justify-between hover:shadow-md transition-shadow">
              <div className="space-y-1">
                <p className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">Active Links</p>
                <p className="text-3xl font-extrabold text-zinc-900 dark:text-zinc-50">{dashboardSummary.cards.activeLinks}</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center">
                <CheckCircle className="w-5 h-5" />
              </div>
            </div>

            {/* Clicks Today */}
            <div className="p-6 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl flex items-center justify-between hover:shadow-md transition-shadow">
              <div className="space-y-1">
                <p className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">Clicks Today</p>
                <p className="text-3xl font-extrabold text-zinc-900 dark:text-zinc-50">{dashboardSummary.cards.clicksToday}</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center">
                <Clock className="w-5 h-5" />
              </div>
            </div>
          </>
        )}
      </div>

      {/* Filter Options */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark p-4 rounded-xl">
        <SearchBar value={searchQuery} onChange={(val) => { setSearchQuery(val); setPage(1); }} placeholder="Search links by destination or code..." />
        
        <div className="flex items-center space-x-3">
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="px-3 py-2 text-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-lg text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="">All Statuses</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* Main Table Panel */}
      {isLoading && urls.length === 0 ? (
        <TableSkeleton />
      ) : urls.length === 0 ? (
        <EmptyState 
          title="No shortened URLs yet" 
          description="It looks like you haven't created any links. Get started by shortening your first destination URL!"
          actionButton={
            <button
              onClick={() => setIsCreateOpen(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg shadow-lg shadow-indigo-600/10 active:scale-[0.98] transition-all"
            >
              Shorten URL
            </button>
          }
        />
      ) : (
        <div className="overflow-hidden border border-border-light dark:border-border-dark rounded-xl bg-card-light dark:bg-card-dark">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-zinc-50 dark:bg-zinc-900/50 text-xs font-semibold uppercase tracking-wider text-zinc-400 border-b border-border-light dark:border-border-dark">
                  <th className="px-6 py-4">Short Code / Title</th>
                  <th className="px-6 py-4">Destination Link</th>
                  <th className="px-6 py-4">Clicks</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Created Date</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border-light dark:divide-border-dark text-sm">
                {urls.map((urlObj) => {
                  const redirectLink = `${window.location.protocol}//${window.location.host.replace('5173', '5000')}/${urlObj.shortCode}`;
                  return (
                    <tr key={urlObj._id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/10 transition-colors">
                      
                      {/* Short Link / Custom Alias */}
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="space-y-0.5">
                          <a 
                            href={redirectLink}
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="flex items-center space-x-1.5 font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                          >
                            <span>/{urlObj.shortCode}</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                          {urlObj.customAlias && (
                            <p className="text-xs text-zinc-400 font-medium">Alias: {urlObj.customAlias}</p>
                          )}
                        </div>
                      </td>

                      {/* Long URL Destination */}
                      <td className="px-6 py-4 max-w-xs truncate text-zinc-500 dark:text-zinc-400">
                        <span title={urlObj.longUrl}>{urlObj.longUrl}</span>
                      </td>

                      {/* Clicks */}
                      <td className="px-6 py-4 whitespace-nowrap font-medium text-zinc-700 dark:text-zinc-200">
                        {urlObj.clicks}
                      </td>

                      {/* Status */}
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getStatusBadge(urlObj.status, urlObj.expiresAt)}
                      </td>

                      {/* Date */}
                      <td className="px-6 py-4 whitespace-nowrap text-xs text-zinc-400">
                        {new Date(urlObj.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                      </td>

                      {/* Row Actions */}
                      <td className="px-6 py-4 whitespace-nowrap text-right text-zinc-400">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => handleCopyLink(urlObj)}
                            className="p-1.5 border border-border-light dark:border-border-dark rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-800 dark:hover:text-zinc-100 transition-colors"
                            title="Copy Short URL"
                          >
                            <Copy className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => { setSelectedUrl(urlObj); setIsQrOpen(true); }}
                            className="p-1.5 border border-border-light dark:border-border-dark rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-800 dark:hover:text-zinc-100 transition-colors"
                            title="View QR Code"
                          >
                            <QrCode className="w-4 h-4" />
                          </button>
                          <Link
                            to={`/analytics/${urlObj._id}`}
                            className="p-1.5 border border-border-light dark:border-border-dark rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-800 dark:hover:text-zinc-100 transition-colors"
                            title="View Analytics"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                          </Link>
                          <button
                            onClick={() => { 
                              setSelectedUrl(urlObj); 
                              setEditUrlData({ longUrl: urlObj.longUrl, expiresAt: urlObj.expiresAt ? urlObj.expiresAt.substring(0, 10) : '' }); 
                              setIsEditOpen(true); 
                            }}
                            className="p-1.5 border border-border-light dark:border-border-dark rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 hover:text-zinc-800 dark:hover:text-zinc-100 transition-colors"
                            title="Edit Link"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => { setSelectedUrl(urlObj); setIsDeleteOpen(true); }}
                            className="p-1.5 border border-red-500/20 rounded-lg hover:bg-red-500/10 text-red-500 transition-colors"
                            title="Delete Link"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
        </div>
      )}

      {/* CREATE LINK MODAL */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between p-5 border-b border-border-light dark:border-border-dark">
              <h3 className="font-semibold text-zinc-900 dark:text-zinc-50">Shorten a new URL</h3>
              <button onClick={() => setIsCreateOpen(false)} className="p-1 rounded-lg text-zinc-400 hover:text-zinc-200">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateLink} className="p-6 space-y-4">
              
              {/* Long URL */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-zinc-500 uppercase">Destination URL *</label>
                <input
                  type="url"
                  required
                  value={newUrlData.longUrl}
                  onChange={(e) => setNewUrlData({ ...newUrlData, longUrl: e.target.value })}
                  placeholder="https://example.com/very-long-link-slug-details"
                  className="block w-full px-3 py-2 text-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              {/* Custom Alias */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-zinc-500 uppercase">Custom Alias (Optional)</label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 rounded-l-lg border border-r-0 border-border-light dark:border-border-dark bg-zinc-100 dark:bg-zinc-800 text-zinc-400 text-xs">
                    /
                  </span>
                  <input
                    type="text"
                    value={newUrlData.customAlias}
                    onChange={(e) => setNewUrlData({ ...newUrlData, customAlias: e.target.value })}
                    placeholder="my-custom-slug"
                    className="block w-full px-3 py-2 text-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-r-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {/* Expiry Date */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-zinc-500 uppercase">Link Expiration (Optional)</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <input
                    type="date"
                    value={newUrlData.expiresAt}
                    onChange={(e) => setNewUrlData({ ...newUrlData, expiresAt: e.target.value })}
                    min={new Date().toISOString().split('T')[0]}
                    className="block w-full pl-10 pr-3 py-2 text-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-border-light dark:border-border-dark">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 text-sm font-semibold border border-border-light dark:border-border-dark rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg shadow-lg shadow-indigo-600/10 active:scale-[0.98] transition-all"
                >
                  Create
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* EDIT LINK MODAL */}
      {isEditOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between p-5 border-b border-border-light dark:border-border-dark">
              <h3 className="font-semibold text-zinc-900 dark:text-zinc-50">Edit shortened link</h3>
              <button onClick={() => setIsEditOpen(false)} className="p-1 rounded-lg text-zinc-400 hover:text-zinc-200">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleEditLink} className="p-6 space-y-4">
              
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-zinc-500 uppercase">Destination URL *</label>
                <input
                  type="url"
                  required
                  value={editUrlData.longUrl}
                  onChange={(e) => setEditUrlData({ ...editUrlData, longUrl: e.target.value })}
                  placeholder="https://example.com"
                  className="block w-full px-3 py-2 text-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-zinc-500 uppercase">Link Expiration (Optional)</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <input
                    type="date"
                    value={editUrlData.expiresAt}
                    onChange={(e) => setEditUrlData({ ...editUrlData, expiresAt: e.target.value })}
                    className="block w-full pl-10 pr-3 py-2 text-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-border-light dark:border-border-dark">
                <button
                  type="button"
                  onClick={() => setIsEditOpen(false)}
                  className="px-4 py-2 text-sm font-semibold border border-border-light dark:border-border-dark rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg shadow-lg shadow-indigo-600/10 active:scale-[0.98] transition-all"
                >
                  Save Changes
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* QR CODE VIEW MODAL */}
      {isQrOpen && selectedUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between p-5 border-b border-border-light dark:border-border-dark">
              <h3 className="font-semibold text-zinc-900 dark:text-zinc-50">QR Code</h3>
              <button onClick={() => { setIsQrOpen(false); setSelectedUrl(null); }} className="p-1 rounded-lg text-zinc-400 hover:text-zinc-200">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 flex flex-col items-center justify-center space-y-6">
              <div className="p-4 bg-white border border-zinc-200 rounded-lg shadow-inner">
                <img 
                  src={selectedUrl.qrCode} 
                  alt={`QR code for ${selectedUrl.shortCode}`} 
                  className="w-48 h-48 block"
                />
              </div>
              <div className="text-center">
                <p className="text-sm font-bold text-zinc-800 dark:text-zinc-200">/{selectedUrl.shortCode}</p>
                <p className="text-xs text-zinc-400 dark:text-zinc-500 max-w-[200px] truncate">{selectedUrl.longUrl}</p>
              </div>
              <a
                href={selectedUrl.qrCode}
                download={`qrcode-${selectedUrl.shortCode}.png`}
                className="w-full flex items-center justify-center space-x-2 py-2 px-4 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg shadow-md transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Download Image</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* DELETE LINK CONFIRMATION MODAL */}
      <ConfirmModal
        isOpen={isDeleteOpen}
        onClose={() => { setIsDeleteOpen(false); setSelectedUrl(null); }}
        onConfirm={handleDeleteLink}
        title="Delete Short Link"
        message="Are you sure you want to delete this shortened link? All associated visit statistics and click history will be permanently deleted. This action cannot be undone."
        confirmText="Delete Link"
      />

    </div>
  );
}
