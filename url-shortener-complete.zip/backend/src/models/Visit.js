const mongoose = require('mongoose');

const VisitSchema = new mongoose.Schema(
  {
    urlId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Url',
      required: true,
      index: true
    },
    timestamp: {
      type: Date,
      default: Date.now,
      index: true
    },
    browser: {
      type: String,
      default: 'Unknown'
    },
    device: {
      type: String,
      default: 'Desktop'
    },
    os: {
      type: String,
      default: 'Unknown'
    },
    referrer: {
      type: String,
      default: 'Direct'
    },
    country: {
      type: String,
      default: 'Unknown'
    },
    city: {
      type: String,
      default: 'Unknown'
    }
  },
  {
    timestamps: true
  }
);

// Compound index for aggregating clicks over time for a specific URL
VisitSchema.index({ urlId: 1, timestamp: -1 });

module.exports = mongoose.model('Visit', VisitSchema);
